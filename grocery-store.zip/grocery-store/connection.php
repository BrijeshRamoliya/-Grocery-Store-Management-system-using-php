<?php 
$con = mysqli_connect('localhost', 'root', '','grocery_store_db');
?>