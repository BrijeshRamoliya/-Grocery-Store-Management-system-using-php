<?php
require './class/atclass.php';
?>


<div class="sticky-header header-section ">
    <div class="header-left">

    </div>
    <div class="header-right">


        <!--search-box-->


        <div class="profile_details">		
            <ul>
                <li class="dropdown profile_details_drop">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                        <div class="profile_img">
                            <from method="POST">

                                <div class="user-name">
                                    <p>Admin</p>
                                    

                                </div>
                            </from>



                        </div>	
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                        <a class="dropdown-item" href="index.php">Dashboard</a>
                                        <a class="dropdown-item" href="index.php?id=userProfile">Profile</a>
                                        <a class="dropdown-item" href="login.php">Log Out</a>
                        </div>
                        <?php
                        if(isset($_POST['Logout']))
                        {
                            session_destroy();
                            header("location: grocery-store/login.php");
                        }
                        
                        
                        ?>
                    </a>

                </li>
            </ul>
        </div>
        <div class="clearfix"> </div>				
    </div>
    <div class="clearfix"> </div>	
</div>