<div class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left" id="cbp-spmenu-s1">
    <!--left-fixed -navigation-->
    <aside class="sidebar-left">
        <nav class="navbar navbar-inverse">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".collapse" aria-expanded="false">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <h1><a class="navbar-brand" href="index.html"><span class=""></span> Grocery Store</a></h1>
            </div>
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="sidebar-menu">
                    <li class="header"></li>
                    <li class="treeview">
                        <a href="AdminDashboard.php">
                            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
                        </a>
                    </li>
                    <li class="treeview">
                        <a href="#">
                            <i class=""></i>Login Record<span></span>
                            <i class="fa fa-angle-left pull-right"></i>
                        </a>
                        <ul class="treeview-menu">
                            <li><a href="LoginRecord.php"><i class="fa fa-angle-right"></i>Login Record</a></li>                           
                        </ul>
                        
                    </li>
                    <li class="treeview">
                        <a href="#">
                            <i class=""></i>
                            <span>Product</span>
                            <i class="fa fa-angle-left pull-right"></i>
                        </a>
                        <ul class="treeview-menu">
                            <li><a href="add-product.php"><i class="fa fa-angle-right"></i> Add Product</a></li>
                            <li><a href="show-product.php"><i class="fa fa-angle-right"></i> View Product</a></li>
                        </ul>
                    </li>
                    
                    
                    <li class="treeview">
                        <a href="#">
                            <i class=""></i>Customer<span></span>
                            <i class="fa fa-angle-left pull-right"></i>
                        </a>
                        <ul class="treeview-menu">
                            <li><a href="customer-record.php"><i class="fa fa-angle-right"></i> Customer Record</a></li>
                            <li><a href="customer-bill.php"><i class="fa fa-angle-right"></i> Customer Bill</a></li>
                            <li><a href="addreview.php"><i class="fa fa-angle-right"></i> Customer Review</a></li>                           
                        </ul>
                        
                    </li>

                    <li class="treeview">
                        <a href="A-ContactUs.php">
                            <i class=""></i>ContactUs<span></span>
                        </a>
                        
                    </li>

                     
                   
                   
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>
    </aside>
</div>