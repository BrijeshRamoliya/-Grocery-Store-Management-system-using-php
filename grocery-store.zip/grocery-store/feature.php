<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gro Mart</title>
    <link rel="stylesheet" href="Grocery Store Design.css">
</head>
<body>
   
<!-- features section start -->

<section class="features" id="features">

    <h1 class="heading"> Our Feature </h1>

    <div class="box-container">

        <div class="box">
            <img src="image/feature-img-1.png" alt="">
            <h3>Fresh And Organic Product</h3>
            <a href="" class=""></a>
        </div>

        <div class="box">
            <img src="image/feature-img-2.png" alt="">
            <h3>Free Delivery</h3>
            <a href="" class=""></a>
        </div>

        <div class="box">
            <img src="image/feature-img-3.png" alt="">
            <h3>Easy Payments</h3>
            <a href="" class=""></a>
        </div>

    </div>

</section>

<!-- features section ends -->
</body>
</html>