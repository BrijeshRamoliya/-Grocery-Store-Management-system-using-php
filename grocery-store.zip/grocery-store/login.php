<?php
require './class/atclass.php';
?>



<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>GM-Admin Login</title>


        <style>
            * {
                margin: 0px;
                padding: 0px;
            }
            body {
                font-size: 120%;
                background: #F8F8FF;
            }

            .header {
                width: 30%;
                margin: 50px auto 0px;
                color: rgb(2, 2, 2);
                background: #f16202;
                text-align: center;
                border: 1px solid #B0C4DE;
                border-bottom: none;
                border-radius: 10px 10px 0px 0px;
                padding: 20px;
            }
            form, .content {
                width: 30%;
                margin: 0px auto;
                padding: 20px;
                border: 1px solid #B0C4DE;
                background: white;
                border-radius: 0px 0px 10px 10px;
            }
            .input-group {
                margin: 10px 0px 10px 0px;
            }
            .input-group label {
                display: block;
                text-align: left;
                margin: 3px;
            }
            .input-group input {
                height: 30px;
                width: 93%;
                padding: 5px 10px;
                font-size: 16px;
                border-radius: 5px;
                border: 1px solid rgb(255, 97, 5);
            }
            .btn {
                padding: 10px;
                font-size: 15px;
                color: rgb(2, 2, 2);
                background: #ff5e00;
                border: none;
                border-radius: 5px;
            }
            .error {
                width: 92%; 
                margin: 0px auto; 
                padding: 10px; 
                border: 1px solid #a94442; 
                color: #a94442; 
                background: #f2dede; 
                border-radius: 5px; 
                text-align: left;
            }
            .success {
                color: #3c763d; 
                background: #dff0d8; 
                border: 1px solid #3c763d;
                margin-bottom: 20px;
            }
        </style>
    </head>
    <body>
        <title></title>
        <link rel="stylesheet" type="text/css" href="style.css">
    </head>
<body>
    <div class="header">
        <h2>Admin</h2>
    </div>

    <form method="post" action="">

        <div class="input-group">
            <label>Username</label>
            <input type="text" name="pusername" required>
        </div>
        <div class="input-group">
            <label>Password</label>
            <input type="password" name="ppassword" required>
        </div>
        <div class="input-group">
            <button type="login" name="login" class="btn">login</button>
        </div>
    </form>
    <?php
    if (isset($_POST['login'])) {
        $query = "SELECT * FROM `tbl_login` WHERE user_name='$_POST[pusername]' and user_password='$_POST[ppassword]'";
        $result = mysqli_query($connection, $query);
        if (mysqli_num_rows($result)) {
            echo "<script>alert('password correct')</script>";
            session_start();
            $_SESSION['AdminLoginId'] = $_POST['pusername'];
            header("location: add-product.php");
        } else {
            echo "<script>alert('password incorrect')</script>";
        }
    }
    ?>
</body>
</html>