<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gro Mart review Page</title>
    <link rel="stylesheet" href="Grocery Store Design.css">
</head>
<body>

    <!-- review section starts  -->

    <header class="header">

    <a href="" class="logo"></i> Gro Mart</a>
    
    <nav class="navbar">
    <button type="button" class="btn btn-light"><a href="useraddreview.php">Add Review</a></button>
    </nav>
    
    </div>

</header>

<section class="review" id="review">

    <h1 class="heading"> Customer's Review </h1>

    <div class="swiper review-slider">

        <div class="swiper-wrapper">

            <div class="swiper-slide box">
                <h3>Customer 1</h3>
                <p>This website is Best. Grocery Store website is usefull in  many people. this website product are best and fresh.Easily available all the products from A to Z with good quality and at least price.</p>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
            </div>

            <div class="swiper-slide box">
                <h3>Customer 2</h3>
                <p>This website is people saving Time  without people going on shop people can shopping to a varies types of products at a home.</p>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
            </div>

            <div class="swiper-slide box">
                <h3>Customer 3</h3>
                <p>Good to see this type of portal, very useful. At the time of festival it's very difficult task to have(storage) all the things at one store, but here I got ample amount of products that I need it.</p>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
            </div>                      
        </div>

    </div>

</section>

<!-- review section ends -->

</body>
</html>