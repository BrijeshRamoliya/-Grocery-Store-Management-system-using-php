<?php

    $con = mysqli_connect("localhost","root","","login_db");
    if(isset($_POST['submit'])){
               
        $imagename = $_FILES['pimg']['name']; //storing image name
        $tempimagename = $_FILES['pimg']['tmp_name']; //temp name 
        //move_uploaded_file($tempimagename,"product_image/$imagename");
        
        $q = mysqli_query($con,"insert into product_table(,p_image) VALUES 
			('{$imagename}')") or die(mysqli_error($con));
		  if($q){
       		echo "<script>alert('Image Uploaded Successfully');</script>";
               //header("location:main_page.php");	
   
        }
    }
?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Admin</title>
    <!-- plugins:css -->
    

                    <form class="forms-sample" action="" method="POST" enctype="multipart/form-data">

                      <div class="form-group">
                        <label for="exampleInputPassword1">Choose Image</label>
                        <input class="form-control" type="file" accept="image/*" name="pimg" required>
                      </div>
                      
                      <button type="submit" class="btn btn-gradient-primary mr-2" name="submit" >Add</button>
                    </form>           
</html>