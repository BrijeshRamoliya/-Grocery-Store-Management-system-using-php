-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 31, 2022 at 07:21 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `grocery_store_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

CREATE TABLE `tbl_customer` (
  `cus_name` varchar(50) NOT NULL,
  `cus_id` varchar(100) NOT NULL,
  `pro_name` varchar(100) NOT NULL,
  `pro_price` int(11) NOT NULL,
  `pro_img` varchar(100) NOT NULL,
  `pro_detail` varchar(100) NOT NULL,
  `pro_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_customer`
--

INSERT INTO `tbl_customer` (`cus_name`, `cus_id`, `pro_name`, `pro_price`, `pro_img`, `pro_detail`, `pro_id`) VALUES
('', '', '', 0, '', '', 0),
('', '', '', 0, '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_login`
--

CREATE TABLE `tbl_login` (
  `user_name` varchar(100) NOT NULL,
  `user_password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_login`
--

INSERT INTO `tbl_login` (`user_name`, `user_password`) VALUES
('Admin', '4325');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE `tbl_product` (
  `pro_id` int(11) NOT NULL,
  `pro_name` varchar(50) NOT NULL,
  `pro_img` varchar(500) NOT NULL,
  `pro_price` varchar(100) NOT NULL,
  `pro_detail` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` (`pro_id`, `pro_name`, `pro_img`, `pro_price`, `pro_detail`) VALUES
(12, 'abc', '', '100 per kg', 'dsds'),
(19, 'abc', '', '100 per kg', 'cbvbvb');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_review`
--

CREATE TABLE `tbl_review` (
  `id` int(11) NOT NULL,
  `u_email` varchar(250) NOT NULL,
  `u_review` varchar(252) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `usertable`
--

CREATE TABLE `usertable` (
  `id` int(50) NOT NULL,
  `name` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `code` mediumtext NOT NULL,
  `status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `usertable`
--

INSERT INTO `usertable` (`id`, `name`, `email`, `password`, `code`, `status`) VALUES
(1, 'df', 'ramoliyabrijesh.98@gmail.com', '$2y$10$36qK5NYNKmcDilsvnId8JuyxB0dKeTk79yhlcmJZ5rwak5FUFm86i', '806639', 'verified'),
(2, 'brij', 'brijesh.ramoliya107740@marwadiuniversity.ac.in', '$2y$10$EgHxMGhSYZzW25gq0TowjOVasII5rH0OFPJFeBPf3XxlWeAMiVRHO', '961556', 'notverified'),
(4, 'Brijesh Ramoliya', 'brijeshramoliya07@gmail.com', '$2y$10$sJ7xToKTinKxR.xBLcoOienmM3ujexCFntBNeBAQSfFpuP3GELekW', '0', 'verified'),
(5, 'abc', 'brramoliya07@gmail.com', '$2y$10$T5uUDx9wAZChhMYMzSbB6O3PDmDs9AGzXdDtEcjEK7eoOTw0PCNDa', '787891', 'notverified'),
(6, 'nayan', 'nayan.kalasha107925@marwadiuniversity.ac.in', '$2y$10$FZag/LjUKo.2reTzn4OeL.t1Z9c6Y.qohf0r9YvTVAPZ22XBwX5Sq', '148286', 'notverified'),
(7, 'rutu', 'rutu95121@gmail.com', '$2y$10$mhNgorMjcvj9AM3tgl1Sne9p0RopTLg68F9zqilXH.5mTXWVZoXLW', '0', 'verified'),
(9, 'rutu', 'solankirutvik104@gmail.com', '$2y$10$nRGg/Q5cpD0lNemDGhIFxORIHQ6Zg6FTDtHSMw4jEB5VnWEQ3Uvda', '0', 'verified');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_product`
--
ALTER TABLE `tbl_product`
  ADD PRIMARY KEY (`pro_id`);

--
-- Indexes for table `tbl_review`
--
ALTER TABLE `tbl_review`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `usertable`
--
ALTER TABLE `usertable`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_product`
--
ALTER TABLE `tbl_product`
  MODIFY `pro_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `tbl_review`
--
ALTER TABLE `tbl_review`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `usertable`
--
ALTER TABLE `usertable`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
