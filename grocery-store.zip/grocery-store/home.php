<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gro Mart</title>

    <link rel="stylesheet" href="Grocery Store Design.css">
</head>
<body>
    


   <!-- home section starts  -->

<section class="home" id="home">

    <div class="content">
        <h3>Fresh And  Organic Product </h3>
        <a href="product.php" class="btn">Shop Now</a>       
    </div>
    

</section>

<!-- home section ends -->




    
</body>
</html>