<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gro Mart</title>
    <link rel="stylesheet" href="Grocery Store Design.css">
</head>
<body>

    <!-- categories section starts  -->

<section class="categories" id="categories">

    <h1 class="heading"> Product Categorie </h1>

    <div class="box-container">

        <div class="box">
            <img src="image/blog-1.jpg" alt="">
            <h3>Vegitables And Fruits</h3>
            <p>upto 60% off</p>
            <a href="" class="btn">shop now</a>
        </div>

        <div class="box">
            <img src="image/blog-2.jpg" alt="">
            <h3>Fresh Masala</h3>
            <p>upto 50% off</p>
            <a href="" class="btn">shop now</a>
        </div>

        <div class="box">
            <img src="image/blog-3.jpg" alt="">
            <h3>Cooking Oil</h3>
            <p>upto 25% off</p>
            <a href="" class="btn">shop now</a>
        </div>

        <div class="box">
            <img src="image/Blog-4.jpg" alt="">
            <h3>Hair Oil</h3>
            <p>upto 10% off</p>
            <a href="" class="btn">shop now</a>
        </div>

    </div>

</section>

<!-- categories section ends -->

</body>
</html>