<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gro Mart</title>
    <link rel="stylesheet" href="Grocery Store Design.css">
</head>
<body>
    <!-- header section starts  -->

<header class="header">

    <a href="grocery-store.php" class="logo"></i> Gro Mart </a>


    <nav class="navbar">
        <a href="vegitables-and-fruits.php">Vegitables & Fruits</a>
        <a href="masala.php">Masala</a>
        <a href="eat-oil.php">Cooking Oil</a>
        <a href="oil-product.php">Hair Oil</a>

       
    </nav>

</header>

<!-- header section ends -->

   
        <!-- blogs section starts  -->
    
    <section class="blogs" id="blogs">
    
        <h1 class="heading"></h1>
    
        <div class="box-container">
    
            <div class="box">
                <img src="image/blog-1.jpg" alt="">
                <div class="content">
                    <div class="icons">
                        <a href="grocery-store.php"> <i class="fas fa-user"></i>Grocery Store</a>
                        <a href=""> <i class="fas fa-calendar"></i></a>
                    </div>
                    <h3>Fresh  Vegitables And Fruits</h3>
                    <a href="vegitables-and-fruits.php" class="btn">Read More Product</a>
                </div>
            </div>
    
            <div class="box">
                <img src="image/blog-2.jpg" alt="">
                <div class="content">
                    <div class="icons">
                        <a href="grocery-store.php"> <i class="fas fa-user"></i>Grocery Store</a>
                        <a href=""> <i class="fas fa-calendar"></i></a>
                    </div>
                    <h3> Fresh Masala</h3>
                    <a href="masala.php" class="btn">Read More Product</a>
                </div>
            </div>
    
            <div class="box">
                <img src="image/blog-3.jpg" alt="">
                <div class="content">
                    <div class="icons">
                        <a href="grocery-store.php"> <i class="fas fa-user"></i>Grocery Store</a>
                        <a href=""> <i class="fas fa-calendar"></i></a>
                    </div>
                    <h3>Cooking Oil</h3>
                    <a href="eat-oil.php" class="btn">Read More Product</a>
                </div>
            </div>
    
            <div class="box">
                <img src="image/Blog-4.jpg" alt="">
                <div class="content">
                    <div class="icons">
                        <a href="grocery-store.php"> <i class="fas fa-user"></i>Grocery Store</a>
                        <a href=""> <i class="fas fa-calendar"></i></a>
                    </div>
                    <h3>Hair Oil</h3>
                    <a href="oil-product.php" class="btn">Read More Product</a>
                </div>
            </div>
    
        </div>
    
    </section>
    
    <!-- blogs section ends -->


<script>
    
    $('.add-to-cart').on('click', function () {
            var cart = $('.shopping-cart');
            var imgtodrag = $(this).parent('.fas fa-trash').find("img").eq(0);
            if (imgtodrag) {
                var imgclone = imgtodrag.clone()
                    .offset({
                    top: imgtodrag.offset().top,
                    left: imgtodrag.offset().left
                })
                    .css({
                    'opacity': '0.8',
                        'position': 'absolute',
                        'height': '150px',
                        'width': '150px',
                        'z-index': '100'
                })
                    .appendTo($('body'))
                    .animate({
                    'top': cart.offset().top + 10,
                        'left': cart.offset().left + 10,
                        'width': 75,
                        'height': 75
                }, 1000, 'easeInOutExpo');
                
                setTimeout(function () {
                    cart.effect("shake", {
                        times: 2
                    }, 200);
                }, 1500);
    
                imgclone.animate({
                    'width': 0,
                        'height': 0
                }, function () {
                    $(this).detach()
                });
            }
        });    
    </script>



</body>
</html>