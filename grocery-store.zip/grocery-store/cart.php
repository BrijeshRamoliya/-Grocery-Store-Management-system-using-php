<?php

session_start();

$pid = $_GET['pid'];
$qty = $_GET['qty'];

if (isset($_SESSION['productcart'])) {
    $currentNo = $_SESSION['counter'] + 1;
    $_SESSION['productcart'][$currentNo] = $pid;
    $_SESSION['qty'][$currentNo] = $qty;

    $_SESSION['counter'] = $currentNo;
} else {
    $productcart = array();
    $qty = array();
    $_SESSION['productcart'][0] = $pid;
    $_SESSION['qty'][0] = $qty;
    $_SESSION['counter'] = 0;
}
header("location: viewcart.php");