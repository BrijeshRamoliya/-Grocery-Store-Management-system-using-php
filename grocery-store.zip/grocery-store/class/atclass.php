<?php

$host = "localhost";
$user = "root";
$password = "";
$database = "grocery_store_db";

$connection = mysqli_connect($host, $user, $password ,$database);



?>
