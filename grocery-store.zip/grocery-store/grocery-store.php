<?php

require './class/atclass.php';
if(isset($_POST['add_review'])){
    $email = mysqli_real_escape_string($connection, $_POST['email']);
    $txt = mysqli_real_escape_string($connection, $_POST['txt']);


    $query = mysqli_query($connection,"insert into tbl_review values('$email','$txt')") or die(mysqli_errno($connection)) ;
        
    if ($query) {
        $msg = '<div class="alert alert-info" role="alert">Record Add success </div>';
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GM-Home</title>

    <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">


    <link rel="stylesheet" href="Grocery Store Design.css">
    

  
<style>
     body{
                padding: 0;
                margin: 0;
                height: 100vh;
                justify-self: center;
                align-items: center;
                background:  #ffffff;
            }
            .section{
                margin: 0;
                padding: 0;
                height: 100vh;
                margin-top: 200px;
                display: flex;
                justify-content: center;

            }
            .slider{
                width: 880px;
                height: 500px;
                border-radius: 10px;
                overflow: hidden;
            }
            .slide{
                width: 500%;
                height: 500px;
                display: flex;

            }
            .slide input{
                display: none;
            }
            .st{
                width: 20%;
                transition: 2s;

            }
            .st img{
                width: 800px;
                height: 500px;

            }
            .nav-m{
                position: absolute;
                width: 800px;
                margin-top: -40px;
                justify-content: center;
                display: flex;

            }
            .nav a.navbar-brand{
        color: #fff;
        font-size: 30px!important;
        font-weight: 500;
    }
            .button a{
        color: #6665ee;
        font-weight: 500;
    }
            .m-btn{
                border: 2px solid  #6d44b8;
                padding: 5px;
                border-radius: 10px;
                cursor: pointer;
                transition: 3s;
            }
            .m-btn:not(:last-child){
                margin-right: 30px;
            }
            .m-btn-hover{
                background-color: #23e3c2;
            }
            #radio1:checked ~.first{
                margin-left: 0;			
            }
            #radio2:checked ~.first{
                margin-left: -20%;			
            }
            #radio3:checked ~.first{
                margin-left: -40%;			
            }
            #radio4:checked ~.first{
                margin-left: -60%;			
            }
            #radio5:checked ~.first{
                margin-left: -80%;			
            }
            .nav-auto{
                position: absolute;
                width: 800px;
                margin-top: 460px;
                display: flex;
                justify-content: center;
            }
            .nav-auto div{
                border: 2px solid #23e3c2;
                padding: 5px;
                border-radius: 10px;
                transition: 3s;
            }
            .nav-auto div:not(:last-child){
                margin-right: 30px;
                justify-content: center;
            }
            #radio1:checked ~ .nav-auto .a-b1{
                background-color: #080808;
            }
            #radio2:checked ~ .nav-auto .a-b2{
                background-color: #0c0c0c;
            }
            #radio3:checked ~ .nav-auto .a-b3{
                background-color: #070707;
            }
            #radio4:checked ~ .nav-auto .a-b4{
                background-color: #070707;
            }
            #radio5:checked ~ .nav-auto .a-b5{
                background-color: #030303;
            }
            
</style>
</head>
<body>
    <div class="footer">
        <div class="box-container">
            <ul>
                <li><a href="Feature.html"></a></li>
                <li><a href="Review.html"></a></li>
            </ul>

        </div>

    </div>
    
<!-- header section starts  -->

<header class="header">

    <a href="" class="logo"></i> Gro Mart</a>


    <nav class="navbar">
        <a href="home.php">Home</a>
        <a href="feature.php">Feature</a>
        <a href="product.php">Product</a>
        <a href="categories.php">Categories</a>
        <a href="review.php">Review</a>
        <a href="ContactUs.php">Contact</a>
    </nav>

    <div class="icons">
        <div class="fas fa-bars" id="menu-btn"></div>
        <div class="fas fa-search" id="search-btn">
        </div>
        <div class="fas fa-shopping-cart" id="cart-btn"></div>
    </div>

  <!--  <form action="" class="search-form">
        <input type="search" id="search-box" placeholder="search here...">
        <label for="search-box" class="fas fa-search"></label>
        
    </form>   -->
    <div>
    
    <nav class="navbar">
    <button type="button" class="btn btn-light"><a href="logout-user.php">Logout</a></button>
    </nav>
    
    </div>

</header>

<!-- header section ends -->

<!-- home section starts  -->

<section class="home" id="home">

    <div class="content">
        <h3>Fresh And  Organic Product </h3>
        <a href="product.php" class="btn">Shop Now</a>
  <!--   <h1>Welcome to<?php echo    $_SESSION['useremail']  ?></h1> !-->
    </div>

</section>
<section class="section">
            <div class="slider">
                <div class="slide">
                    <input type="radio" name="radio-btn" id="radio1">
                    <input type="radio" name="radio-btn" id="radio2">
                    <input type="radio" name="radio-btn" id="radio3">
                    <input type="radio" name="radio-btn" id="radio4">
                    <input type="radio" name="radio-btn" id="radio5">

                    <div class="st first">
                        <img src="./image/blog-1.jpg" alt="">
                    </div>
                    <div class="st ">
                        <img src="./image/blog-6.jpg" alt="">
                    </div>
                    <div class="st ">
                        <img src="./image/blog-5.jpg" alt="">
                    </div>
                    <div class="st ">
                        <img src="./image/blog-2.jpg" alt="">
                    </div>
                    <div class="st ">
                        <img src="./image/Blog-4.jpg" alt="">
                    </div>

                    <div class="nav-auto">
                        <div class="a-b1"></div>
                        <div class="a-b2"></div>
                        <div class="a-b3"></div>
                        <div class="a-b4"></div>
                        <div class="a-b5"></div>

                    </div>

                </div>
                <div class="nav-m">
                    <label for="radio1" class="m-btn"></label>
                    <label for="radio2" class="m-btn"></label>
                    <label for="radio3" class="m-btn"></label>
                    <label for="radio4" class="m-btn"></label>
                    <label for="radio5" class="m-btn"></label>
                </div>


            </div>

        </section>

<!-- home section ends -->


<!-- footer section starts  -->

<section class="footer">

    <div class="box-container">

        <div class="box">
            <h3> Grocery Store <i class=""></i> </h3>
            <div class="share">
                <a href="" class="fab fa-facebook-f"></a>
                <a href="" class="fab fa-twitter"></a>
                <a href="" class="fab fa-instagram"></a>
                <a href="" class="fab fa-linkedin"></a>
            </div>
        </div>

        <div class="box">
            <h3>contact info</h3>
            <a href="" class="links"> <i class="Phone No"></i> +91 76984 69952 </a>
            <a href="" class="links"> <i class="phone No"></i> +91 97264 59356 </a>
            <a href="" class="links"> <i class="Email Id"></i> ramoliyabrijesh.98@gmail.com </a>
            <a href="" class="links"> <i class="Email Id"></i> nayan.kalasha2222@gmail.com </a>
            <a href="" class="links"> <i class="fas fa-map-marker-alt"></i> Gujarat, india</a>
        </div>


        <div class="box">
            <h3>Link</h3>
            <a href="home.php" class="links"> <i class="fas fa-arrow-right"></i> Home </a>
            <a href="feature.php" class="links"> <i class="fas fa-arrow-right"></i> Feature </a>
            <a href="product.php" class="links"> <i class="fas fa-arrow-right"></i> Product </a>
            <a href="categories.php" class="links"> <i class="fas fa-arrow-right"></i> Categorie </a>
            <a href="review.php" class="links"> <i class="fas fa-arrow-right"></i> Review </a>
            <a href="ContactUs.php" class="links"><i class="fas fa-arrow-right"></i> Contact </a>
        </div>

    </div>
    


</section>


<!-- footer section ends -->





<script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>

<!-- custom js code  -->
<script>
    var counter = 1;
            setInterval(function () {
                document.getElementById('radio' + counter).checked = true;
                counter++;
                if (counter > 5) {
                    counter = 1;
                }
            }, 5000);
    let searchForm = document.querySelector('.search-form');

document.querySelector('#search-btn').onclick = () =>{
    searchForm.classList.toggle('active');
    shoppingCart.classList.remove('active');
    loginForm.classList.remove('active');
    navbar.classList.remove('active');
}

let shoppingCart = document.querySelector('.shopping-cart');



document.querySelector('#cart-btn').onclick = () =>{
    shoppingCart.classList.toggle('active');
    searchForm.classList.remove('active');
    loginForm.classList.remove('active');
    navbar.classList.remove('active');
}

let loginForm = document.querySelector('.login-form');

document.querySelector('#login-btn').onclick = () =>{
  
    loginForm.classList.toggle('active');
    searchForm.classList.remove('active');
    shoppingCart.classList.remove('active');
    navbar.classList.remove('active');
}

let navbar = document.querySelector('.navbar');

document.querySelector('#menu-btn').onclick = () =>{
    navbar.classList.toggle('active');
    searchForm.classList.remove('active');
    shoppingCart.classList.remove('active');
    loginForm.classList.remove('active');
}

window.onscroll = () =>{
    searchForm.classList.remove('active');
    shoppingCart.classList.remove('active');
    loginForm.classList.remove('active');
    navbar.classList.remove('active');
}

var swiper = new Swiper(".product-slider", {
    loop:true,
    spaceBetween: 20,
    autoplay: {
        delay: 7500,
        disableOnInteraction: false,
    },
    centeredSlides: true,
    breakpoints: {
      0: {
        slidesPerView: 1,
      },
      768: {
        slidesPerView: 2,
      },
      1020: {
        slidesPerView: 3,
      },
    },
});

var swiper = new Swiper(".review-slider", {
    loop:true,
    spaceBetween: 20,
    autoplay: {
        delay: 7500,
        disableOnInteraction: false,
    },
    centeredSlides: true,
    breakpoints: {
      0: {
        slidesPerView: 1,
      },
      768: {
        slidesPerView: 2,
      },
      1020: {
        slidesPerView: 3,
      },
    },
});
</script>

</body>
</html>