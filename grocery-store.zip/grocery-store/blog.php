<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gro Mart</title>
    <link rel="stylesheet" href="Grocery Store Design.css">
</head>
<body>
    <!-- blogs section starts  -->

<section class="blogs" id="blogs">

    <h1 class="heading">  Our Blog </h1>

    <div class="box-container">

        <div class="box">
            <img src="image/blog-1.jpg" alt="">
            <div class="content">
                <div class="icons">
                    <a href=""> <i class="fas fa-user"></i>Grocery Store</a>
                    <a href=""> <i class="fas fa-calendar"></i></a>
                </div>
                <h3>Fresh  Vegitables And Fruits</h3>
                <a href="" class="btn">read more</a>
            </div>
        </div>

        <div class="box">
            <img src="image/blog-2.jpg" alt="">
            <div class="content">
                <div class="icons">
                    <a href=""> <i class="fas fa-user"></i>Grocery Store</a>
                    <a href=""> <i class="fas fa-calendar"></i></a>
                </div>
                <h3> Fresh Masala</h3>
                <a href="" class="btn">read more</a>
            </div>
        </div>

        <div class="box">
            <img src="image/blog-3.jpg" alt="">
            <div class="content">
                <div class="icons">
                    <a href=""> <i class="fas fa-user"></i>Grocery Store</a>
                    <a href=""> <i class="fas fa-calendar"></i></a>
                </div>
                <h3>Fresh Oil</h3>
                <a href="" class="btn">read more</a>
            </div>
        </div>

    </div>

</section>

<!-- blogs section ends -->
</body>
</html>